## Установка пакетов

```sh
npm install
```

## Запуск всех тестов 

```sh
npm run test
```