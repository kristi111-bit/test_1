// Задача 1. Функция принимает colorByRole аргумент role в виде строки 'admin' или 'manager' или 'unit'
// 1.1 если role не соответствует одной из трех строк, то вернуть значение 'invalid'
// 1.2 если аргумент role отсутствует (null или undefined), то вернуть 'default'
// 1.3 если аргумент role соответствует одной из трех, то вернуть строку типа: 'admin-color' или 'manager-color' или 'unit-color'
// использовать конструкцию switch case

function colorByRole (role) { // colorByRole - возвращает соответствующий цвет в зависимости от role
  switch (role) { //switch - позволяет выбирать различные ветви выполнения кода на основе значения выражения. Оальтернативa -> if-else.
    case 'admin':          //case - метка внутри блока switch. Определяет, какое действие выполнить, если значение выражения в switch соответствует значению этой метки.
      return 'admin-color';
    case 'manager':
      return 'manager-color';
    case 'unit':
      return 'unit-color';
    case null:
    case undefined:
      return 'default';
    default:
      return 'invalid';
  }
}

console.log('Задача 1:', colorByRole('admin')); 
console.log(colorByRole('manager')); 
console.log(colorByRole('unit')); 
console.log(colorByRole('employee')); // проверка (- invalid)
console.log(colorByRole(null)); // проверка (- default)

//---------------------------------------------------------------------------------------------

// Задача 2. Фукнция sortByIncrease принимает в виде аргумента несортированный массив с числами.
//   Сортировать по возрастанию и вернуть отсортированный массив
function sortByIncrease (arr) {
  return arr.sort((a, b) => a - b); //стрелочная функция. Можно использовать их здесь для того, чтобы сортировка выглядела более аккуратной
}

console.log('Задача 2:', sortByIncrease([1, 3, 7, 2, 5, 10, 0, -1]), '- сортировка по возрастанию массива [1, 3, 7, 2, 5, 10, 0, -1]'); 

//-------------------------------------------------
module.exports = { colorByRole, sortByIncrease }

