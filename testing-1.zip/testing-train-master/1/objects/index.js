// Задача 1. Написать функцию simple, которая:
// 1.1) Из объекта user удалить ключ work.
//   1.2) добавить ключ location, со значением 'Rostov-on-Don'
// Вернуть объект
function simple() {
  const user = {
    age: 12,
    phone: '7-###-###-##-##',
    username: 'Anton',
    work: 'developer'
  };

  delete user.work; // Удаление
  user.location = 'Rostov-on-Don'; // Добавление

  return user;
}

console.log('Задача 1:',simple());

//----------------------------------------------------------

// Задача 2.Написать функцию deleteByArg, которая:
// удалит из объекта user, ключ по аргументу key
// вернуть объект
function deleteByArg (key) {
  const user = {
    age: 12,
    phone: '7-###-###-##-##',
    username: 'Anton',
    work: 'developer'
  };

  delete user[key]; //удалит из объекта user, ключ по аргументу key
  return user;
}

console.log('Задача 2:', deleteByArg ('username'));

//--------------------------------------------------------------------------------------------

// Задача 3.Написать функцию combine, которая:
// принимает на вход два объекта и объединяет их в один
// Вместо объектов(или одного из них) также может прийти null, в таком случае вернуть "invalid"
function combine (obj1, obj2) {
  if (typeof obj1 === 'object' && typeof obj2 === 'object') // Проверка, 2 аргумента являются объектами
    if (obj1 !== null && obj2 !== null) {  // Проверка, 2 объекта не равны null
      return { ...obj1, ...obj2 }; // Объединяем свойства обоих объектов и возвращаем результат
    } else {
      return 'invalid';
  }
}
console.log(combine({ a: 100, b: 17 }, { c: 31, d: 79 }));
console.log(combine(null, { c: 79, d: 55 }));

//-------------------------------------------------------------------------------------------------------------

//Задача 4. Написать функцию countProperties, которая принимает на вход объект и выводит количество его свойств.
// Объект (obj) может быть пустым {}
function countProperties(obj) {
  return Object.keys(obj).length; // массив, содержащий все свойства объекта. length -  кол-во элементов (св-в) в массиве
}

const Objects = {
  name: 'Anna',
  age: 27,
  phone: '7-###-###-##-##',
  city: 'New York',
  pet: 'dog'

};

console.log('Задача 3:',countProperties(Objects), '- количество св-в');

//----------------------------------------------------------------
module.exports = { simple, deleteByArg, combine, countProperties }