// Задача 1. Написать функцию findString, которая принимает на вход строку search
// Функция должна искать элемент в массиве kitchen
// без учета регистра (т.е. если на вход приходит 'spoon' или 'Spoon', должно вернуться 'spoon').
// Если элемент в функции не найден, она должна вернуть строку "empty"

function findString(search) {
  const kitchen = ['plate', 'spoon', 'pot', 'table'];
  
  const lowerCaseSearch = search.toLowerCase(); // приводим поиск к нижнему регистру
  
  for (let item of kitchen) {
    if (item.toLowerCase() === lowerCaseSearch) {
      return item; // возвращаем эл-т из массива, если он найден
    }
  }
  return 'empty'; // возвращаем 'empty', если эл-т не найден
}

console.log('Задача 1:', findString('Spoon'), ' - эл-т найден');
console.log(findString('cup'), ' эл-т не найден');

//--------------------------------------------------------------------------------------------------------------------

// Задача 2. Написать функцию findAndDelete, которая принимает на вход строку search
// Функция должна искать элемент в массиве kitchen и удалять его
// возвращать массив

function findAndDelete(search) {
  const kitchen1 = ['cat', 'dog', 'fish'];
  const index = kitchen1.indexOf(search);
  if (index !== -1) {
    kitchen1.splice(index, 1);
  }
  return kitchen1;
}

console.log('Задача: 2',findAndDelete('dog'));

//--------------------------------------------------------------------------------------------------

// Задача 3. Написать функцию findAndReplace, которая принимает на вход строку search и массив
// Функция должна в массиве kitchen находить позицию по индексу (index) и заменять оставшиеся элементы на элементы из массива arr
// вернуть массив kitchen

function findAndReplace(index, arr) {
  const kitchen = ['apple', 'banana', 'carrot', 'date'];
    if (index >= 0)
    if (index < kitchen.length) {
      kitchen.splice(index + 1, kitchen.length - index - 1, ...arr); // Замена оставшихся эле-тов массива 
    }
    return kitchen;
  }

console.log('Задача 3:', findAndReplace(1, ['grape', 'kiwi']));

//--------------------------------------------------------------------------------------------------------------------------------

// Задача 4. Написать функцию filterEvenNumbers, которая принимает на вход массив чисел arr.
// Вернуть новый массив, содержащий только четные числа.

let evenNumbers = filterEvenNumbers([-2, -1, 2, 4, 5, 7, 8, 9]);
function filterEvenNumbers(arr) {
  return arr.filter(num => num % 2 === 0); //filter - возвращает массив из всех подходящих элементов. num => num % 2 === 0 -> Проверка на четность
}

console.log('Задача 4:',evenNumbers, '- только четные числа из массива [-2, -1, 2, 4, 5, 7, 8, 9]');

//---------------------------------------------------------------------

// Задача 5. Написать функцию squareNumbers, которая принимает на вход массив чисел arr.
// вернуть массив, где каждое число возведено в квадрат.

let square = squareNumbers([1, 2, 3, 4, 5]);
function squareNumbers(arr) {
  return arr.map(num => num ** 2); map() //map - вызывается для массива.  num ** 2 - происходит возведение в квадрат каждого эл-та.
}

console.log('Задача 5:', square , '- квадраты чисел:[1, 2, 3, 4, 5] '); 

//----------------------------------------------------------------------------------------------
module.exports = { findString, findAndDelete, findAndReplace, filterEvenNumbers, squareNumbers }